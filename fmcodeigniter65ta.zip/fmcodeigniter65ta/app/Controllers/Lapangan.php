<?php

namespace App\Controllers;

class Lapangan extends BaseController
{
    public function inputLapangan()
    {
        $data = [
            'title' => 'Input Lapangan',
            'page' => 'Lapangan',
            'content' => 'v_input_lapangan'
        ];
        echo view('layout/v_wrapper', $data);
    }
}
