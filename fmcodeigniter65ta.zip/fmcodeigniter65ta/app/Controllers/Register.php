<?php

namespace App\Controllers;

use App\Models\UserModel;

class Register extends BaseController
{
    public function index()
    {
        return view('admin/v_register');
    }
    protected $userModel;

    public function __construct()
    {
        $model = new UserModel();
    }

    public function proses()
    {
        $model = new UserModel();
        $data = array(
            'nama' => $this->request->getPost('nama'),
            'email' => $this->request->getPost('email'),
            'no_hp' => $this->request->getPost('nomor hp'),
            'username' => $this->request->getPost('username'),
            'password' => $this->request->getPost('password'),
        );
        $model->simpanuser($data);

        session()->setFlashdata('berhasil', 'Username dan Password berhasil ditambahkan');
        return redirect()->to(base_url('/'));
    }
}
