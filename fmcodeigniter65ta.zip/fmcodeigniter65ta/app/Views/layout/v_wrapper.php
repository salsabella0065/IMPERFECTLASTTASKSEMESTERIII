<?php
echo view('layout/v_head');
echo view('layout/v_navbar');
echo view('layout/v_sidebar');
echo view('layout/v_content');
echo view('layout/v_footer');
?> 